Usage:
python3 A1.py

Function q6_step1(img) contains the logic of how to run q6 step1,
and q6_test(img) contains the logic of how to run q6 test (step 4).
It will generate the q6_step1.jpg and q6_test.jpg.
You can change the image directory by change the line under `if __name__ == '__main__':`