Usage:

All code are in CSC420_A2.ipynb. All tasks except task 5 are before the text marked 'Task 5'. All models including task2 simple CNN models are all below text marked 'Models'.
To run the model, change all usage in fit_one_cycle with the model changed to the desired one (also change to_device function to let the model use GPU).
The result are marked below text 'Plot' part.